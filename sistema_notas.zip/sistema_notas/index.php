<?php
session_start();
if (isset($_SESSION['loggedin'])) {
    $rol = $_SESSION['rol'];
    $url = $rol == 'Administrador' ? 'views/admin/dashboard.php' :
           ($rol == 'Docente' ? 'views/docente/dashboard.php' : 'views/estudiante/notas_view.php');
    header("Location: $url");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Notas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); height: 100vh; display: flex; align-items: center; }
        .login-card { background: white; border-radius: 15px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); padding: 2.5rem; max-width: 420px; width: 100%; }
        .btn-login { background: #667eea; border: none; }
        .btn-login:hover { background: #5a6fd8; }
    </style>
</head>
<body>
    <div class="login-card mx-auto">
        <div class="text-center mb-4">
            <i class="fas fa-graduation-cap text-primary" style="font-size: 3rem;"></i>
            <h3 class="mt-3 text-primary">Sistema de Notas</h3>
        </div>
        <form action="login.php" method="POST">
            <div class="mb-3">
                <label class="form-label">Usuario</label>
                <input type="text" name="usuario" class="form-control" required value="admin_bautista">
            </div>
            <div class="mb-3">
                <label class="form-label">Contraseña</label>
                <input type="password" name="clave" class="form-control" required value="admin123">
            </div>
            <button type="submit" class="btn btn-login text-white w-100">Iniciar Sesión</button>
        </form>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger mt-3">Credenciales incorrectas.</div>
        <?php endif; ?>
        <div class="mt-4 p-3 bg-light rounded small">
            <strong>Usuarios de prueba:</strong><br>
            admin_bautista / admin123<br>
            docente_bautista / docente123<br>
            estu_dayanara / estu123
        </div>
    </div>
</body>
</html>