<?php
require_once __DIR__ . '/../config/db.php';

class UserModel {
    private $pdo;

    public function __construct() {
        $this->pdo = connect_app_db();
    }

    public function authenticate($nombre_usuario, $clave) {
        $stmt = $this->pdo->prepare("SELECT u.usuario_id, u.nombre_usuario, r.nombre_rol 
                                     FROM usuarios u 
                                     INNER JOIN roles r ON u.rol_id = r.rol_id 
                                     WHERE u.nombre_usuario = ? AND u.clave = ?");
        $stmt->execute([$nombre_usuario, $clave]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>