<?php
require_once __DIR__ . '/../config/db.php';

class NotaModel {
    private $pdo;

    public function __construct() {
        $this->pdo = connect_app_db();
    }

    public function inscribir_estudiante($usuario, $nombre, $apellido, $cedula) {
        try {
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("INSERT INTO usuarios (nombre_usuario, clave, rol_id) VALUES (?, ?, 3)");
            $stmt->execute([$usuario, $usuario . '123']);

            $usuario_id = $this->pdo->lastInsertId();

            $stmt = $this->pdo->prepare("INSERT INTO estudiantes (usuario_id, nombre, apellido, cedula) VALUES (?, ?, ?, ?)");
            $stmt->execute([$usuario_id, $nombre, $apellido, $cedula]);

            $this->pdo->commit();
            return ['status' => 'success', 'message' => 'Estudiante inscrito con éxito.'];
        } catch (Exception $e) {
            $this->pdo->rollBack();
            return ['status' => 'error', 'message' => 'Error: ' . $e->getMessage()];
        }
    }

    public function actualizar_nota_con_auditoria($nota_id, $nueva_nota, $usuario_id) {
        try {
            $this->pdo->beginTransaction();

            $stmt = $this->pdo->prepare("SELECT nota FROM notas WHERE nota_id = ?");
            $stmt->execute([$nota_id]);
            $nota_anterior = $stmt->fetchColumn();

            $stmt = $this->pdo->prepare("UPDATE notas SET nota = ? WHERE nota_id = ?");
            $stmt->execute([$nueva_nota, $nota_id]);

            $stmt = $this->pdo->prepare("INSERT INTO auditoria_notas (nota_id, nota_anterior, nota_nueva, usuario_modificador) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nota_id, $nota_anterior, $nueva_nota, $usuario_id]);

            $this->pdo->commit();
            return ['status' => 'success', 'message' => 'Nota actualizada y auditada.'];
        } catch (Exception $e) {
            $this->pdo->rollBack();
            return ['status' => 'error', 'message' => 'Error: ' . $e->getMessage()];
        }
    }

    public function eliminar_estudiante_completo($estudiante_id, $usuario_id) {
        try {
            $this->pdo->beginTransaction();

            $this->pdo->exec("DELETE FROM notas WHERE estudiante_id = '$estudiante_id'");
            $this->pdo->exec("DELETE FROM estudiantes WHERE estudiante_id = '$estudiante_id'");
            $this->pdo->exec("DELETE FROM usuarios WHERE usuario_id = '$usuario_id'");

            $this->pdo->commit();
            return ['status' => 'success', 'message' => 'Estudiante eliminado completamente.'];
        } catch (Exception $e) {
            $this->pdo->rollBack();
            return ['status' => 'error', 'message' => 'Error: ' . $e->getMessage()];
        }
    }
}
?>