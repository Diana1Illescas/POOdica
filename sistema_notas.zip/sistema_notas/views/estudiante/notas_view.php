<?php 
require_once '../../config/db.php';
require_once '../layout/header.php'; 

$pdo = connect_user_db($_SESSION['db_user'], $_SESSION['db_pass']);
$notas = $pdo->query("SELECT * FROM vw_mis_notas")->fetchAll();
?>

<h1>Bienvenido, <?= $_SESSION['nombre_usuario'] ?> (Estudiante)</h1>

<h2>Mis Calificaciones</h2>
<table class="table table-bordered">
    <tr><th>Materia</th><th>Nota</th><th>Fecha</th></tr>
    <?php foreach ($notas as $n): ?>
    <tr>
        <td><?= $n['nombre_materia'] ?></td>
        <td><?= $n['nota'] ?></td>
        <td><?= $n['fecha_registro'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>

<?php require_once '../layout/footer.php'; ?>