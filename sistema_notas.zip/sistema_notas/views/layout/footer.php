    </div>
    <footer class="bg-dark text-white text-center py-4 mt-5">
        <p>© 2025 Sistema de Notas Bautista | Demostración de Seguridad y Transacciones</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>