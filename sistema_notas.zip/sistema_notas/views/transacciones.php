<?php 
session_start();
require_once '../models/NotaModel.php';
$output = "";
$result = ['status' => '', 'message' => ''];
require_once 'layout/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['transaccion'])) {
    $model = new NotaModel();
    $id = $_POST['transaccion'];
    if ($id == 1) $result = $model->inscribir_estudiante('estu_mariana_2', 'Mariana', 'Vera', '2350083060');
    elseif ($id == 2) $result = $model->actualizar_nota_con_auditoria('N00006', 75.00, 'U00002');
    elseif ($id == 3) $result = $model->eliminar_estudiante_completo('E00002', 'U00004');
    $class = $result['status'] == 'success' ? 'success' : 'error';
    $output = "<div class='alert alert-$class'>{$result['message']}</div>";
}
?>

<div class="card">
    <div class="card-header bg-danger text-white">
        <h3>Transacciones ACID</h3>
    </div>
    <div class="card-body">
        <?php echo $output; ?>
        <form method="POST">
            <button name="transaccion" value="1" class="btn btn-info m-2">Inscribir Estudiante</button>
            <button name="transaccion" value="2" class="btn btn-warning m-2">Actualizar Nota</button>
            <button name="transaccion" value="3" class="btn btn-danger m-2">Eliminar Estudiante</button>
        </form>
    </div>
</div>

<?php require_once 'layout/footer.php'; ?>