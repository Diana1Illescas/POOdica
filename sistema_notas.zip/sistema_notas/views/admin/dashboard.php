<?php require_once '../layout/header.php'; ?>
<div class="row">
    <div class="col-md-12">
        <div class="card shadow-sm border-primary">
            <div class="card-header bg-primary text-white">
                <h4><i class="fas fa-user-shield"></i> Panel Administrador</h4>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    <strong>MySQL User:</strong> <code><?= $_SESSION['db_user'] ?></code> 
                    <span class="badge bg-success">ALL PRIVILEGES</span>
                </div>
                <h5>Demostraciones</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <a href="../transacciones.php" class="btn btn-outline-danger w-100 p-3">
                            <i class="fas fa-database fa-2x"></i><br>
                            <strong>Transacciones ACID</strong>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../layout/footer.php'; ?>