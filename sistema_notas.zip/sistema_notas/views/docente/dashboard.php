<?php 
require_once '../../config/db.php';
require_once '../layout/header.php'; 

$pdo = connect_user_db($_SESSION['db_user'], $_SESSION['db_pass']);
$notas = $pdo->query("SELECT n.*, e.nombre, e.apellido, m.nombre_materia FROM notas n JOIN estudiantes e ON n.estudiante_id = e.estudiante_id JOIN materias m ON n.materia_id = m.materia_id")->fetchAll();
?>

<div class="card shadow-sm">
    <div class="card-header bg-success text-white">
        <h4><i class="fas fa-chalkboard-teacher"></i> Panel Docente</h4>
    </div>
    <div class="card-body">
        <div class="alert alert-success">
            <strong>Permisos:</strong> CRUD en <code>notas</code>
        </div>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-primary">
                    <tr><th>Estudiante</th><th>Materia</th><th>Nota</th><th>Acción</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($notas as $n): ?>
                    <tr>
                        <td><?= $n['nombre'] . ' ' . $n['apellido'] ?></td>
                        <td><?= $n['nombre_materia'] ?></td>
                        <td>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="nota_id" value="<?= $n['nota_id'] ?>">
                                <input type="number" name="nueva_nota" value="<?= $n['nota'] ?>" class="form-control form-control-sm d-inline w-auto" step="0.1">
                                <button name="update_nota" class="btn btn-sm btn-primary"><i class="fas fa-save"></i></button>
                            </form>
                        </td>
                        <td>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="delete_nota" value="<?= $n['nota_id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
if (isset($_POST['update_nota'])) {
    $id = $_POST['nota_id'];
    $nota = $_POST['nueva_nota'];
    $pdo->prepare("UPDATE notas SET nota = ? WHERE nota_id = ?")->execute([$nota, $id]);
    echo "<script>location.reload();</script>";
}
if (isset($_POST['delete_nota'])) {
    $pdo->prepare("DELETE FROM notas WHERE nota_id = ?")->execute([$_POST['delete_nota']]);
    echo "<script>location.reload();</script>";
}
require_once '../layout/footer.php'; 
?>