<?php
// En una aplicación real, este controlador manejaría las peticiones POST del login,
// llamaría al UserModel para autenticar y redirigiría la vista.
// Actualmente, la lógica está simplificada en login.php.

class AuthController {
    // public function login() { ... }
    // public function logout() { ... }
}
