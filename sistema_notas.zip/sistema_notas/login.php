<?php
session_start();
require_once 'config/db.php';
require_once 'models/UserModel.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $model = new UserModel();
    $user = $model->authenticate($_POST['usuario'], $_POST['clave']);

    if ($user) {
        $_SESSION['loggedin'] = true;
        $_SESSION['nombre_usuario'] = $user['nombre_usuario'];
        $_SESSION['rol'] = $user['nombre_rol'];

        $map = [
            'Administrador' => ['admin_bautista', 'admin123', 'views/admin/dashboard.php'],
            'Docente' => ['docente_bautista', 'docente123', 'views/docente/dashboard.php'],
            'Estudiante' => ['estudiante_bautista', 'estu123', 'views/estudiante/notas_view.php']
        ];

        $data = $map[$user['nombre_rol']];
        $_SESSION['db_user'] = $data[0];
        $_SESSION['db_pass'] = $data[1];
        header("Location: " . $data[2]);
        exit;
    } else {
        header('Location: index.php?error=1');
        exit;
    }
} else {
    header('Location: index.php');
    exit;
}
?>